# 更新记录
## 1.4.0 - 2019.12.18
* 增加 Dark Mode 支持

## 1.3.0 - 2019.10.7
* 增加 `gitalk` 和 `valine` 支持

## 1.2.0
* 增加 `gitment` 支持
* 移除多说

## 1.1.0
* 增加对关闭文章评论的支持 [issue#14](https://github.com/CodeDaraW/Hacker/issues/14)
* 增加对分类和标签的支持 [issue#7](https://github.com/CodeDaraW/Hacker/issues/7)

## 1.0.1
* 修复了主页上错误的评论链接

## 1.0
* 修复从文件夹导致的 bug [issue#10](https://github.com/CodeDaraW/Hacker/issues/10)
* 修复 `code` 标签的显示效果


## 0.3
* 重构 ejs 模板
* 改用 stylus
* 添加英文文档


## 0.2
* 去除部分无用 css 和重复 css
* 修复无分类/标签依然出现 icon 的 bug
* 重写归档列表页面
* 修改代码块样式
